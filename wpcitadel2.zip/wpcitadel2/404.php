<?php
include ($ccache['base_path'] . '/div-title.php');
include ($ccache['base_path'] . '/div-header.php');
?>

<div id='main-wrapper' class='singlephp'>
<section id='content'>
	<h1>Error 404 - Page Not Found :(</h1>
</section>

<section id="search_form">
	<?php get_search_form(); ?>
</section>

</div>

<?php
include ($ccache['base_path'] . '/div-footer.php');
?>
